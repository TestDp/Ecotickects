<?php $__env->startSection('content'); ?>
<div class="row title text-center">
								<h2 class="black">CUPONES ECOTICKETS</h2>
	</div>
    <table id="TablaListaCupones" class="table table-bordered">
        <thead>
        <tr >

            <th >
                Nombre
            </th>
            <th >
                Lugar
            </th>
            <th >
                Ciudad
            </th>
            <th >
                Departamento
            </th>
            <th >
                Fecha del Evento
            </th>
            <th >
                Fecha Inicial de registro
            </th>
            <th >
                Fecha Final de registro
            </th>
            <th></th>
        </tr>
        </thead>
        <tfoot>
        <tr >

            <th >
                Nombre
            </th>
            <th >
                Lugar
            </th>
            <th >
                Ciudad
            </th>
            <th >
                Departamento
            </th>
            <th >
                Fecha del Evento
            </th>
            <th >
                Fecha Inicial de registro
            </th>
            <th >
                Fecha Final de registro
            </th>
            <th></th>
        </tr>
        </tfoot>
        <tbody >
        <?php $__currentLoopData = $ListaEventos["eventos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td >
                    <?php echo e($evento->Nombre_Evento); ?>

                </td>
                <td >
                    <?php echo e($evento->Lugar_Evento); ?>

                </td>
                <td >
                    <?php echo e($evento->ciudad->Nombre_Ciudad); ?>

                </td>
                <td>
                    <?php echo e($evento->ciudad->departamento->Nombre_Departamento); ?>

                </td>
                <td >
                    <?php echo e($evento->Fecha_Evento); ?>

                </td>
                <td >
                    <?php echo e($evento->Fecha_Inicial_Registro); ?>

                </td>
                <td>
                    <?php echo e($evento->Fecha_Final_Registro); ?>

                </td>
                <td><a class="btn btn-blue ripple trial-button" href="<?php echo e(url('FormularioAsistente', ['idEvento' => $evento->id ])); ?>">Registrarse</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.eventos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>