<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">Información del Evento </div>
        <div class="panel-body">
            <?php $__currentLoopData = $ElementosArray["evento"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InformacionEvento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Id:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->id); ?>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-8">Nombre:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Tipo_Evento); ?>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Tipo:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Nombre_Evento); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Lugar:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Lugar_Evento); ?>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-8">Ciudad:</label>
                        <div class="col-md-10">

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Departamento:</label>
                        <div class="col-md-10">

                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Fecha:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Fecha_Evento); ?>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-8">Fecha Incial de resgistro:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Fecha_Inicial_Registro); ?>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label class="col-md-7">Fecha Final de resgistro:</label>
                        <div class="col-md-10">
                            <?php echo e($InformacionEvento->Fecha_Final_Registro); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <form action="<?php echo e(url('registrarAsistente')); ?>" method="POST">
        <input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" id="Evento_id" name="Evento_id" value="<?php echo e($ElementosArray["EventoId"]); ?>">
        <div class="row">
            <div class="col-md-6">
                Nombre
                <input id="Nombres" name="Nombres" type="text" class="form-control" />
            </div>
            <div class="col-md-6">
                Apellidos
                <input id="Apellidos" name="Apellidos" type="text" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                Identificación
                <input id="Identificacion" name="Identificacion" type="text" class="form-control" />
            </div>
            <div class="col-md-6">
                Celular/teléfono
                <input id="telefono" name="telefono" type="text" class="form-control" />
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                Email
                <input id="Email" name="Email" type="text" class="form-control" />
            </div>
            <div class="col-md-6">
                Confirmar Email
                <input id="confEmail" name="confEmail" type="text" class="form-control" />
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                Edad
                <input id="Edad" name="Edad" type="number" class="form-control" />
            </div>
            <div class="col-md-6">
                Dirección
                <input id="Dirección" name="Dirección" type="text" class="form-control" />
            </div>
        </div>
        <div class="row">

            <div class="col-md-4">
                Departamento persona
                <select id="Departamento_id" name="Departamento_id" onchange="CargarMunicipiosDepartamento()" class="form-control">
                    <option value="">Seleccionar</option>
                    <?php $__currentLoopData = $ElementosArray["departamentos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($Departamento->id); ?>"><?php echo e($Departamento->Nombre_Departamento); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                Ciudad Persona
                <select id="Ciudad_id" name="Ciudad_id" class="form-control">

                </select>
            </div>
        </div>
        <div class="col-md-6">
            Comentario
            <input id="ComentarioEvento" name="ComentarioEvento" type="text" class="form-control" />
        </div>
        <br/>
        <div class="column one">

            <div class="hover_color_wrapper">
                <h2 style="font-size: 20px; font-family: sans-serif; color:#2297e1;">Responde por favor la siguiente encuesta</h2>
                <?php $__currentLoopData = $ElementosArray["preguntas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PreguntasFormulario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <fieldset>
                        <div style="font-weight:700; font-family: sans-serif; padding-top: 2%;" name ="id_pregunta" value = "<?php echo e($PreguntasFormulario->id); ?>"><?php echo e($PreguntasFormulario->Enunciado); ?> </div>
                        <?php $__currentLoopData = $PreguntasFormulario->Respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuestas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6" >
                                <div class="radio">
                                    <div style="font-family: sans-serif; line-height: 30px;"><input type="radio" value="<?php echo e($respuestas->id); ?>" id="Respuesta_id" name="Respuesta_id[<?php echo e($loop->parent->index); ?>]" >
                                        <b><?php echo e($respuestas->EnunciadoRespuesta); ?></b>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label for="Respuesta_id[<?php echo e($loop->index); ?>]" class="error" style="display:none;">Please choose one.</label>
                    </fieldset>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
        <br/>
        <div class="row">
            <div class="col-md-8 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    Registrarse
                </button>
            </div>
        </div>
    </form>
    <script src="<?php echo e(asset('js/Evento/eventos.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>