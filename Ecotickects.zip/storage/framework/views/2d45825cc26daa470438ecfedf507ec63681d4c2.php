<?php $__env->startSection('content'); ?>
<section style="background:#ffffff; padding-top:40px !important;" class="section section-padded blue-bg">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="owl-twitter owl-carousel">
						<div class="item text-center">
							<img src="<?php echo e(asset('img/icono.png')); ?>">
							<h3 style="color:#db0000;" class="white light">El número de identificación <?php echo e($identificacion); ?> ya se encuentra registrado.</h3>
							<h4 style="color:#db0000;" class="light-white light">Por favor verifica la información ingresada e intenta de nuevo.</h4>
						</div>						
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eventos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>