<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading">Estadísticas </div>
        <div class="panel-body">
            <input type="hidden" id="idevento" value="<?php echo e($idEvento); ?>">
            <input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="row">
                <div class="col-sm-6">
                    <canvas id="canvas" class="img-responsive"></canvas>
                </div>
                <div class="col-sm-6">
                    <canvas id="canvasBarra" class="img-responsive"></canvas>
                </div>
            </div>
        </div>
    </div>



    <script src="<?php echo e(asset('js/Evento/eventos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Plugins/Jquery/jquery-3.1.1.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Plugins/Chart/Chart.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            construirGrafico();
            construirBarras();
        });
    </script>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.eventos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>