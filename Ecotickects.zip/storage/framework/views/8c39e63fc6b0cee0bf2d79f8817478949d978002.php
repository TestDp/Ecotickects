<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading text-center"><h3>Lista de Asistentes</h3></div>
                    <div class="panel-body">
                        <table id="TablaListaAsistentes"  class="table table-bordered">
                            <thead>
                            <tr >
                                <th>
                                    Identificación
                                </th>
                                <th>
                                    Nombre
                                </th>
                                <th>
                                    Apellidos
                                </th>
                                <th>
                                    Celular
                                </th>
                                <th>
                                    Correo
                                </th>
                                <th>
                                    Ciudad
                                </th>
                            </tr>
                            </thead>
                            <tbody >
                            <?php $__currentLoopData = $ListaAsistentes["Asistentes"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <th>
                                  <?php echo e($asistente->Identificacion); ?>

                                </th>
                                <th>
                                    <?php echo e($asistente->Nombres); ?>

                                </th>
                                <th>
                                    <?php echo e($asistente->Apellidos); ?>

                                </th>
                                <th>
                                    <?php echo e($asistente->telefono); ?>

                                </th>
                                <th>
                                    <?php echo e($asistente->Email); ?>

                                </th>
                                <th>
                                    <?php echo e($asistente->ciudad->Nombre_Ciudad); ?>

                                </th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <script src="<?php echo e(asset('js/Evento/eventos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Plugins/Jquery/jquery-3.1.1.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            var table = $('#TablaListaAsistentes').DataTable({
                dom: 'B<"clear">lfrtip',
                buttons: {
                    name: 'primary',
                    text: 'Save current page',
                    buttons: [
                        { extend: 'excel', text: '<p style="color: green !important; font-size: 20px; text-align: center;"><img src="http://estebanquinteroc.com/wp-content/uploads/2017/10/icono-excel.png"></img>Exportar lista</p>' }
                    ]
                },
                language: {
                    "lengthMenu": "Registros por página _MENU_",
                    "info":"Mostrando del _START_ a _END_ de _TOTAL_ registros",
                    "infoEmpty":"Mostrando del 0 a 0 de 0 registros",
                    "infoFiltered": "(Registros filtrados _MAX_ )",
                    "zeroRecords": "No hay registros",
                    "search": "Buscador:",
                    "paginate": {
                        "first":      "First",
                        "last":       "Last",
                        "next":       "Siguiente",
                        "previous":   "Anterior"
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.eventos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>