<?php
/**
 * Created by PhpStorm.
 * User: LaPoint
 * Date: 24/01/2018
 * Time: 9:25 PM
 */

namespace Eco\Interfaces\InterfazManager;


class InterfazManager
{

}